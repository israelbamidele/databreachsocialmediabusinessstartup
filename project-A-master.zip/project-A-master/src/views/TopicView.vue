<template>
   <div>
      <TheTopic/>
   </div>
</template>
<script>

import TheTopic from '../components/TheTopics.vue';

export default {
   name:'topic-view',
   components: {
      TheTopic,
   }
}
</script>
<template>
  <div class="about">
    <TheForum/>
  </div>
</template>
<script>

import TheForum from '@/components/TheForum.vue';

export default {
  name:'ForumView',
  components: {
    TheForum,
  }
}
</script>
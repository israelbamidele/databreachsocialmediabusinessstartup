<template>
   <div>
      <TheDiscussion/>
   </div>
</template>
<script>

import TheDiscussion from '@/components/TheDiscussion.vue';

export default {
   name:'DiscussionView',
   components: {
      TheDiscussion,
   }
}
</script>
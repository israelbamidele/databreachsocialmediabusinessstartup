export function getLength(value){
   return value.length;
}
